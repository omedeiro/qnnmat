function setAttenuation(obj, attenuation)
fprintf(obj, ['ATT ', num2str(attenuation),' dB']);
end