classdef sim900
    %AWG Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        inst
        console
    end
    
    methods
        function obj = sim900(GPIB_Address)
            if ~exist('GPIB_Address')
                GPIB_Address = 7;
            end
            obj.inst = gpib('ni',0, GPIB_Address);
            fopen(obj.inst);
            
            %             con = console('ni');
            %             obj.inst = inst(con, GPIB_Address);
            %             obj.console = con;
            %             obj.clearErrors();
            
        end
        
        
        function txt = read(obj)
            txt = fscanf(obj.inst);
        end
        
        function write(obj, string)
            fprintf(obj.inst,[string]);
        end
        
        function setLevel(obj, voltage, sim900port)
            message = sprintf('VOLT %0.4e', voltage);
            fprintf(obj.inst,['SNDT '  num2str(sim900port)  ',"' message '"']);
            %              obj.clearErrors();
            
        end
        
        function setOutput(obj, status, sim900port)
            if status == 1
                message = sprintf('OPON');
                fprintf(obj.inst,['SNDT '  num2str(sim900port)  ',"' message '"']);
            else
                message = sprintf('OPOF');
                fprintf(obj.inst,['SNDT '  num2str(sim900port)  ',"' message '"']);
            end
        end
        
        
        
        function Close(obj)
            fclose(obj.inst);
        end
        
    end
    
end

% PYTHON DRIVER


% import pyvisa
%
% class SIM928(object):
%     """Python class for SRS SIM928 Isolated Voltage Source inside a SIM900
%     mainframe, written by Adam McCaughan"""
%     def __init__(self, sim900port, visa_name):
%         rm = pyvisa.ResourceManager()
%         self.pyvisa = rm.open_resource(visa_name)
%         self.pyvisa.timeout = 5000 # Set response timeout (in milliseconds)
%         # self.pyvisa.query_delay = 1 # Set extra delay time between write and read commands
%         self.sim900port = sim900port
%         # Anything else here that needs to happen on initialization
%
%     def read(self):
%         return self.pyvisa.read()
%
%     def write(self, string):
%         self.pyvisa.write(string)
%
%     def query(self, string):
%         return self.pyvisa.query(string)
%     def write_simport(self, message):
%         write_str = 'SNDT ' + str(self.sim900port) + ',\"' + message + '\"'
%         # print write_str
%         self.write(write_str) # Format of 'SNDT 4,\"GAIN 10\"'
%     def ask_simport(self, message):
%         write_str = 'SNDT ' + str(self.sim900port) + ',\"' + message + '\"'
%         return self.query(write_str) # Format of 'SNDT 4,\"GAIN 10\"'
%     def reset(self):
%         self.write_simport('*RST')
%     def set_voltage(self, voltage=0.0):
%         # In a string, %0.4e converts a number to scientific notation
%         self.write_simport('VOLT %0.4e' %(voltage))
%     def set_output(self, output=False):
%         if output==True:
%             self.write_simport('OPON')
%         else:
%             self.write_simport('OPOF')  # Only uses "OPOF" or "OPON": "OPOFF" does not work
%
%
