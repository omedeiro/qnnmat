function setBlanker(obj, blanking)
fprintf(obj, ['D ', num2str(blanking)]);
end