classdef spectrum_an
    %aq6317 Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        inst
    end
    
    methods
        
        function obj = spectrum_an(GPIB_Address)
            if ~exist('GPIB_Address')
                GPIB_Address = 7;
            end
            

            obj.inst = inst('ni', GPIB_Address);

%             obj.clearErrors();
        end
%         function obj = spectrum_an()            
% %             obj = gpib('ni',0,1);  
%              obj = serial('COM3');                  %Set COM Port
% %             status=get(obj1,'status');
% % 
% %             if strcmp(status,'closed')
% %                 obj = serial('COM3');
% %             else
% %                 fclose(obj1);
% %                 obj = obj1;
% %             end
%             fopen(obj);     
%         end
        
        function openConnection(obj)
            fopen(obj);                              %Opens connection to the spectrum analyzer
            idn=query(obj,'*IDN?');
            disp(['Connected to: ' idn(1:4) ' ' idn(6:12)])           
            obj.Terminator = 'CR/LF';
            set(obj,'InputBufferSize',10*20001);     %Creates enough space for data
            set(obj,'Timeout',60);                   %Code times out if it exceeds 60secs
            obj.clearErrors();
        end
        
        function setStart(obj, wl)
            query(obj,['STAWL' num2str(wl)]); %create start wavelength command
            obj.clearErrors();
        end
        
        function setStop(obj, wl)
            query(obj,['STPWL' num2str(wl)]); %create stop wavelength command 
            obj.clearErrors();
        end
        
        function setCenter(obj, wl)
            query(obj,['CTRWL' num2str(wl)]); %create center wavelength command 
            obj.clearErrors();
        end
        
        function setSpan(obj, wl)
            query(obj,['SPAN' num2str(wl)]); %create span command 
            obj.clearErrors();
        end        
           
        function setReference(obj, ref)
            query(obj,['REFL' num2str(ref)]); %create reference command
            obj.clearErrors();
        end
        
        function setLevelScale(obj, scale)
            query(obj,['LSCL' num2str(scale)]); %create level scale command
            obj.clearErrors();
        end
           
        function setResolution(obj, res)
            query(obj,['RESLN' num2str(res)]); %create resolution command  
            obj.clearErrors();
        end
      
        function setSamplingPoint(obj, smp)
            query(obj,['SMPL' num2str(smp)]);
            obj.clearErrors();
        end
        
        function [wavelength, level] = acquireSweep(obj, trace)
            query(obj,'SGL');
            disp('Retreiving Wavelength...')
            wave=str2double(query(obj,['WDAT' trace ]));        %Acquires wavelength data
            disp('Retreiving Level...')
            value=str2double(query(obj,['LDAT' trace ]));       %Acquires level data
            wavelength=wave(2:end)';                            %Crops out relevant data
            level=value(2:end);
            obj.clearErrors();
            return 
        end       
        
        function closeConnection(obj)
            fclose(obj);                                        % Close connection to GPIB
            set(obj,'InputBufferSize',512);                     % Resets InputBufferSize
        end
        
        function clearErrors(obj)
                error = 1;
            while error
                errorstr = query(obj,'WARN?');

                % error checking
                if strncmp (errorstr, '0,"No error"',12)
                    error = 0;
                else
                   errorcheck = ['Error reported: ', errorstr];
                   fprintf (errorcheck)
                end
            end                       
        end
        
    end
    
end
